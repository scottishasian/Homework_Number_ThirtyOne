package example.codeclan.com.liskov;

/**
 * Created by user on 27/06/2017.
 */

public class Square  extends Shape{
}
