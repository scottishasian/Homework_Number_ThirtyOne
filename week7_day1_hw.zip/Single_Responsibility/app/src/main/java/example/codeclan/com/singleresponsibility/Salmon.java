package example.codeclan.com.singleresponsibility;

/**
 * Created by user on 27/06/2017.
 */

public class Salmon {
}
