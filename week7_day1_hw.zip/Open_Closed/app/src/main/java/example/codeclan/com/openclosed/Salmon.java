package example.codeclan.com.openclosed;

/**
 * Created by user on 27/06/2017.
 */

public class Salmon {
}
